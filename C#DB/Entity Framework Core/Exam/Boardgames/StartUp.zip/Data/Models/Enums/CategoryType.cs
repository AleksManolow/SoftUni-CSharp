﻿namespace Boardgames.Data.Models.Enums
{
    public enum CategoryType
    {
        Abstract,
        Children,
        Family,
        Party,
        Strategy
    }
}
