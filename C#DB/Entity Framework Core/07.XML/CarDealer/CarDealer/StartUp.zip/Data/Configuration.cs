﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = 
            @"Server=DESKTOP-AJ5FISA\SQLEXPRESS;Database=CarDealer;Integrated Security = True;TrustServerCertificate=True;";
    }
}
