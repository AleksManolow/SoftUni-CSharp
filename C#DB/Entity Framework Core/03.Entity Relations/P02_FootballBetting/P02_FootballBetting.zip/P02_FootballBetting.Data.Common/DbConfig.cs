﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString =
            @"Server=DESKTOP-AJ5FISA\SQLEXPRESS;Database=bet365;Integrated Security = True;TrustServerCertificate=True;";
    }
}