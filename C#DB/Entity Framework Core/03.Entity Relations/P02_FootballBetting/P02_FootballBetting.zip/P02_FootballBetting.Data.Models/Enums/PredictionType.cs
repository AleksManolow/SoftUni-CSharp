﻿namespace P02_FootballBetting.Data.Models.Enums
{
    public enum PredictionType
    {
        x = 0,
        HomeTeam = 1,
        AwayTeam = 2
    }
}
