﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
                        @"Server=DESKTOP-AJ5FISA\SQLEXPRESS;Database=Theatre;Integrated Security = True;TrustServerCertificate=True;";
    }
}
