﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-AJ5FISA\SQLEXPRESS;Database=Artillery;Integrated Security = True;TrustServerCertificate=True;";
    }
}
