﻿namespace SoftJail.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-AJ5FISA\SQLEXPRESS;Database=SoftJail;Integrated Security = True;TrustServerCertificate=True;";
    }
}
