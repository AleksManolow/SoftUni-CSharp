﻿namespace Formula1.Models
{
    public class Ferrari : FormulaOneCar
    {
        public Ferrari(string model, double engineDisplacement, int horsepower)
            : base(model, engineDisplacement, horsepower)
        {
        }
    }
}
